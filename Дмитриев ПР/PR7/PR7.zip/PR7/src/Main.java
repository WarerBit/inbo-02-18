import java.util.Stack;
import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Stack<Integer> p1 = new Stack<>();
        Stack<Integer> p2 = new Stack<>();
        for(int i = 0; i < 5;i++)
            p1.push(sc.nextInt());
        for(int i = 0; i < 5;i++)
            p2.push(sc.nextInt());
        Game.drunkard(p1,p2);
    }
}
