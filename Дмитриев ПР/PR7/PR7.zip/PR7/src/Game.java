import java.util.Stack;
public class Game {
    public static void drunkard(Stack<Integer> stack1,Stack<Integer> stack2){
        int roundcount = 0;
        while(!stack1.empty() && !stack2.empty() && roundcount != 106){
            if (stack1.firstElement() > stack2.firstElement()){
                if ((stack2.firstElement() != 0 )||((stack2.firstElement() == 0 )&&(stack1.firstElement() != 9))){
                    stack1.push(stack1.firstElement());
                    stack1.remove(stack1.firstElement());
                    stack1.push(stack2.firstElement());
                    stack2.remove(stack2.firstElement());
                }
                else{
                    stack2.push(stack2.firstElement());
                    stack2.remove(stack2.firstElement());
                    stack2.push(stack1.firstElement());
                    stack1.remove(stack1.firstElement());
                }

            }
            else{
                if ((stack1.firstElement() != 0) || ((stack1.firstElement() == 0) && (stack2.firstElement() != 9))) {
                    stack2.push(stack2.firstElement());
                    stack2.remove(stack2.firstElement());
                    stack2.push(stack1.firstElement());
                    stack1.remove(stack1.firstElement());
                }
                else{
                    stack1.push(stack1.firstElement());
                    stack1.remove(stack1.firstElement());
                    stack1.push(stack2.firstElement());
                    stack2.remove(stack2.firstElement());
                }
            }
            roundcount++;
        }
        if (stack1.empty())
            System.out.println("Second "+roundcount);
        else
            System.out.println("First "+roundcount);
    }
}
