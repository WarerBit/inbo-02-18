public class Main {
    public static void main(String[] args){
        Ball b1 = new Ball(30,5);
        Ball b2 = new Ball();
        Ball b3 = new Ball(5,1);
        b2.setRadius(b1.getRadius()-b3.getRadius());
        b2.setWeight(b1.getWeight()-b3.getWeight());
        System.out.println("Ball 1:" +b1.toString());
        System.out.println("\nBall 2:"+b2.toString());
        System.out.println("\nBall 3:"+b3.toString());
    }
}