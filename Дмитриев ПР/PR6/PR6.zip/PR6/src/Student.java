import java.lang.*;
public class Student {
    private String name;
    private int ID;
    public Student(){
        name = "N/A";
        ID = 0;
    }
    public Student(String name,int ID){
        this.name = name;
        this.ID = ID;
    }
    public int getID(){
        return this.ID;
    }
    public String toString(){
        return "Name:"+this.name+", ID:"+this.ID;
    }
}
