public class Main {
    public static void main(String[] args) {
        Student[] StudArr = new Student[3];
        StudArr[0] = new Student("Pavel",5569);
        StudArr[1] = new Student("Rita",9823);
        StudArr[2] = new Student("Grisha",1009);
        System.out.println("Не отсортированный массив:");
        for(Student Stud : StudArr) {
            System.out.println(Stud);
        }
        System.out.println("\nОтсортированный массив:");
        Sort.Sorting(StudArr);
        for(Student Stud : StudArr) {
            System.out.println(Stud);
        }
    }
}
