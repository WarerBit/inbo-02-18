public class Sort {
    public static void Sorting(Student[] arr) {
        boolean sorted = false;
        int count = 0;
        while(!sorted) {
            sorted = true;
            int min = 9999;
            int index = 0;
            for (int i = count; i < arr.length; i++) {
                if (arr[i].getID() < min) {
                    min = arr[i].getID();
                    index = i;
                }
            }
            if (min != 9999) {
                Student swap = arr[count];
                arr[count] = arr[index];
                arr[index] = swap;
                count++;
                sorted = false;
            }
        }
    }
}
