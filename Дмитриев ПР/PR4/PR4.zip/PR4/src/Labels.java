import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class Labels extends JFrame {
    JButton ACMilan = new JButton("Score AC Milan");
    JButton RealMadrid = new JButton("Score Real Madrid");
    int ScoreACM,ScoreRM;
    JLabel Score = new JLabel("Score: 0 X 0");
    JLabel LastScorer = new JLabel("Last Scorer: N/A");
    JLabel WINNER = new JLabel("Winner: DRAW");
    Labels(){
        super("Football!");
        ScoreACM = 0;
        ScoreRM = 0;
        setLayout(null);
        setSize(500,300);
        ACMilan.setBounds(50,50,150,50);
        RealMadrid.setBounds(300,50,150,50);
        Score.setBounds(210,50,150,50);
        LastScorer.setBounds(210,100,150,50);
        WINNER.setBounds(210,150,150,50);
        add(ACMilan);
        add(RealMadrid);
        add(Score);
        add(LastScorer);
        add(WINNER);
        ACMilan.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ScoreACM++;
                Score.setText("Score:" + ScoreACM + " X " + ScoreRM);
                LastScorer.setText("Last Scorer: AC Milan");
                if (ScoreACM > ScoreRM)
                    WINNER.setText("Winner: AC Milan");
                else if (ScoreACM < ScoreRM)
                    WINNER.setText("Winner: Real Madrid");
                else
                    WINNER.setText("Winner: DRAW");
            }
        });
        RealMadrid.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ScoreRM++;
                Score.setText("Score:" + ScoreACM + " X " + ScoreRM);
                LastScorer.setText("Last Scorer: Real Madrid");
                if (ScoreACM > ScoreRM)
                    WINNER.setText("Winner: AC Milan");
                else if (ScoreACM < ScoreRM)
                    WINNER.setText("Winner: Real Madrid");
                else
                    WINNER.setText("Winner: DRAW");
            }
        });
        setVisible(true);
    }
}
