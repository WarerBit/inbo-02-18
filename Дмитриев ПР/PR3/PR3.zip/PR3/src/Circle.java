public class Circle extends Shape {
    protected double radius;
    public Circle(){
        color = "White";
        filled = true;
        radius = 0;
    }
    public Circle(double radius){
        color = "White";
        filled = true;
        this.radius = radius;
    }
    public Circle(double radius,String color,boolean filled){
        this.color = color;
        this.filled = filled;
        this.radius = radius;
    }
    public double getRadius(){
        return this.radius;
    }
    public void setRadius(double radius){
        this.radius = radius;
    }
    public double getPerimeter(){
        return 3.14*2*this.radius;
    }
    public double getArea(){
        return 3.14*this.radius*this.radius;
    }
    public String toString(){
        return "\nCircle:\nColor - "+this.color+"\nFilled - "+this.filled+"\nRadius - "+this.radius+"\nArea - "+getArea()+"\nPerimeter - "+getPerimeter();
    }
}
