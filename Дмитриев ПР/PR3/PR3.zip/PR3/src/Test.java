public class Test {
    public static void main(String[] args) {
        Shape s1 = new Circle(5.5, "RED", false); 
        System.out.println(s1);


        Circle c1 = (Circle)s1;
        System.out.println(c1);



        Shape s4 = new Square(6.6);
        System.out.println(s4);


        Rectangle r2 = (Rectangle)s4;
        System.out.println(r2);


        Square sq1 = (Square)r2;
        System.out.println(sq1);
    }
}
