public class Square extends Rectangle {
    public Square(){
        color = "White";
        filled = true;
        width = 0;
        length = 0;
    }
    public Square(double side){
        color = "White";
        filled = true;
        width = side;
        length = side;
    }
    public Square(String color,boolean filled,double side){
        this.color = color;
        this.filled = filled;
        width = side;
        length = side;
    }
    public double getSide(){
        return this.width;
    }
    public void setSide(double side){
        width = side;
        length = side;
    }
    public void setWidth(double side){
        width = side;
        length = side;
    }
    public void setLength(double side){
        width = side;
        length = side;
    }
    public String toString(){
        return "\nSquare:\nColor - "+this.color+"\nFilled - "+this.filled+"\nSide - "+this.width+"\nArea - "+getArea()+"\nPerimeter - "+getPerimeter();
    }
}
