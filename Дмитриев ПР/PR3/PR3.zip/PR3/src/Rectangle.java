public abstract class Rectangle extends Shape {
    protected double width;
    protected double length;
    public Rectangle(){
        color = "White";
        filled = true;
        width = 0;
        length = 0;
    }
    public Rectangle(double width,double length){
        color = "White";
        filled = true;
        this.width = width;
        this.length = length;
    }
    public Rectangle(double width,double length,String color,boolean filled){
        this.color = color;
        this.filled = filled;
        this.width = width;
        this.length = length;
    }
    public double getWidth(){
        return this.width;
    }
    public double getLength(){
        return this.length;
    }
    public void setWidth(double width){
        this.width = width;
    }
    public void setLegth(double length){
        this.length = length;
    }
    public double getArea(){
        return this.width*2+this.length*2;
    }
    public double getPerimeter(){
        return this.width*this.length;
    }
    public String toString(){
        return "\nRectangle:\nColor - "+this.color+"\nFilled - "+this.filled+"\nWidth - "+this.width+"\nLength - "+this.length+"\nArea - "+getArea()+"\nPerimeter - "+getPerimeter();
    }
}
