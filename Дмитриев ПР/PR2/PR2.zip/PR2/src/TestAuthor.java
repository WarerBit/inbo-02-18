public class TestAuthor {
    public static void main(String[] args) {
        Author a1 = new Author("Pavel","pashtet@yandex.ru",'M');
        System.out.println("Author info:"+a1.toString());
        System.out.println("\nChange email to cherepasha@gmail.com");
        a1.setEmail("cherepasha@gmail.com");
        System.out.println("Author info:"+a1.toString());
    }
}